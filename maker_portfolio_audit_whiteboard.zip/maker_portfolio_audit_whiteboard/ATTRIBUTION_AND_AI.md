# Attribution and AI Assistance

Principles applied: a commit under your name does not prove you typed its
contents. A `Co-Authored-By: Claude` trailer does not prove Claude conceived
the idea. Where the repository is silent, this file says **UNDETERMINED**.

## 1. What the repository records

| Fact | Source | Status |
|---|---|---|
| All 3 commits authored and committed by "Ryker Kollmyer <ryker.kollmyer@gmail.com>" | `git log --format='%an %ae'` | VERIFIED |
| **All 3 commits** carry `Co-Authored-By: Claude Opus 5 (1M context)` and a `Claude-Session:` link | commit bodies of `b4bde13`, `6be22e6`, `0a999a4` | VERIFIED |
| Two Claude Code sessions: `session_01PEMay3JkUCYgJfcGLZ9ntH` (commits 1–2), `session_018UExetvr4UGAWWgeyGembV` (commit 3) | trailers | VERIFIED |
| v1 (1592 lines, 19 files) committed 14 min after `pyproject.toml` was created | mtimes + `b4bde13` | VERIFIED |
| No teammate, contributor or external-author credit anywhere | grep of repo; no AUTHORS/CONTRIBUTING | VERIFIED |
| One authorial voice across all code comments, docstrings, README, commit messages, and `out/send/NOTES.txt`: long explanatory prose, `--` dashes, British spelling ("colour") | reading every file | VERIFIED (observation) |

**Reading of that evidence (INFERRED, not proven).** The *text* of the code,
tests, README and commit messages was very probably written by Claude inside
those sessions. That is consistent with a 1592-line commit appearing in 14
minutes and with the uniform prose style. The repository does **not** record
the prompts, so it cannot show who supplied the problem framing, requirements,
milestone plan ("M1–M6"), physical model, or decisions to change direction.
**Session transcripts at the two `claude.ai/code/session_…` URLs are the only
evidence that could settle authorship of ideas.** Open them before claiming any
specific idea as yours. See `QUESTIONS_FOR_ME.md` Q1–Q3.

## 2. Work that is clearly human and physical

| Contribution | Evidence | Who |
|---|---|---|
| Running the board shoot: 56 photos, Samsung SM-G981U, 2026-09-25 11:37–11:42 | EXIF | **UNDETERMINED** (whoever held the phone; presumably you) |
| Calibration photos (bare board, "Hello" in teal), iPad, 2026-09-08 and 09-15 | EXIF | UNDETERMINED (presumably you) |
| 59 hand-lassoed crops (screenshots 2026-09-26 01:04–01:12) | files | UNDETERMINED. These are manual segmentation work in an image editor. The README calls this "the part a person does in a second". |
| The handwriting itself | photos | Students and staff (third parties). **Not your work and not yours to publish without consent.** |
| Duplicate cull (9 copies moved to `send/alt/*_dupe.png`) and acceptance review | `out/send/alt/` | UNDETERMINED (you, a recipient, or Claude) |
| Supplying the real-photo failure cases that drove both fix commits | `6be22e6` and `0a999a4` messages | Photos supplied by the repo owner: VERIFIED. Diagnosing the failures: UNDETERMINED |

## 3. Open-source libraries (reused, not authored)

Algorithms the project *uses* but did not invent. Credit them on the card.

| Library | Used for | Where |
|---|---|---|
| OpenCV (`opencv-python-headless`, locked 5.0.0.93) | Canny, Otsu, `approxPolyDP`, perspective warp, median blur, morphology, **Telea inpainting**, distance transform, connected components, **SIFT**, **FLANN**, **RANSAC homography** | `rectify.py`, `normalize.py`, `clean.py`, `stickers.py`, `recut.py` |
| NumPy | all array math | everywhere |
| Pillow (+ optional `pillow-heif`) | EXIF-aware load, RGBA I/O, HEIC | `io.py` |
| Typer | CLI | `cli.py` |
| MediaPipe Selfie Segmentation (optional) | person masking; the only learned model | `people.py` |
| pytest, hatchling, uv | tests, build, lockfile | `pyproject.toml` |

**Standard techniques, not novel:** compositing / alpha-matting inversion
(`ink = 1 − (1−obs)/α` follows directly from the Porter–Duff "over" operator),
background division for illumination flattening, Lowe's ratio test, RANSAC,
union-find. What is project-specific is *how they were combined and tuned
against failures on real photos*: the darkest-channel glare test, the
chroma-masked refit, the crop-edge litter rule, letter-height merging, and the
shape-AND-colour duplicate rule.

## 4. Work done outside the repository (provenance gap)

14 of the 47 delivered stickers in `out/send/` are **not** reproducible from
the committed code:

* 12 replaced by a "film-removal pass" (`NOTES.txt`). No code with that name or
  function exists in any commit (`git log --all -p | grep -i film` finds only a
  README sentence about glare).
* `sticker_23`: substituted from the larger duplicate and processed with the same pass.
* `sticker_50`: rotated, glare gap interpolated, **coverage lifted** (contrast boost).
  The repo's `--boost-sat` boosts saturation, not coverage.

Who made these edits, and with what tool, is UNDETERMINED. If any delivered
sticker appears on the card, either use one of the 33 byte-identical outputs or
label it "hand-corrected".

## 5. Safe phrasing for the card

* ✅ "Designed and directed, with AI pair-programming (Claude Code), a
  classical computer-vision pipeline… I shot and hand-segmented the dataset,
  found the failures on real photos, and verified fixes against regression tests."
  Claim only the parts you confirm in Q1–Q3.
* ✅ "Built on OpenCV (SIFT, RANSAC, Telea inpainting)."
* ❌ "I wrote 2,800 lines of Python." The repository does not support it.
* ❌ "I invented an ink-unmixing algorithm." The equation is standard compositing algebra.
* ❌ Any delivered sticker shown as raw pipeline output when it is one of the 14 modified files.
