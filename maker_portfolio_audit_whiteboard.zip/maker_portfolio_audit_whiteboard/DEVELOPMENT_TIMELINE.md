# Development Timeline — `wbx` Whiteboard Quote Extractor ("Olympus_Whiteboard")

Reconstructed from: 3 git commits (`git log --all`), file modification times
(`stat`), EXIF timestamps in the photos, and the parameter sets recorded in each
run's `manifest.json`. All times are local (UTC−7, from commit metadata).

**Caveat on mtimes.** File mtimes record the *last* write, not authorship, and
can be reset by copies or checkouts. They are used here only to order events
that git does not record. Every row says which kind of evidence it rests on.

| # | When | Event | Evidence | Status |
|---|---|---|---|---|
| 0 | 2026-09-08 10:10 | Project scaffolded (`pyproject.toml`, `uv.lock` 10:15) | mtimes of `pyproject.toml`, `uv.lock` | VERIFIED (mtime) |
| 1 | 2026-09-08 10:24 | **v1 — full pipeline, "M1–M6".** 19 files, +1592 lines in one commit: rectify → normalize → matte → unmix → clean → stickers, contact sheet, optional HEIC + MediaPipe person masking, synthetic-board test suite. | commit `b4bde13` | VERIFIED |
| 1a | same | The whole pipeline arrives 14 min after the scaffold, in one commit, co-authored by Claude in session `session_01PEMay3…`. The development of v1 is not recorded at all. | `b4bde13` trailers; mtimes 10:10–10:21 | VERIFIED (fact) / INFERRED (that v1 was mostly AI-generated in-session) |
| 2 | 2026-09-08 10:52 | First real test photos: `nomarker.jpeg` (bare board) and `exampletext.jpeg` ("Hello", teal marker), taken on an iPad at 3264×2448 | EXIF DateTime 10:52:12 / 10:52:24, Make=Apple Model=iPad | VERIFIED |
| 3 | 2026-09-08 13:06 | **v1.1 — two bugs found by the real photos.** (a) Rectification invented a board quad from the lighting gradient (the Otsu fallback). Fix: reject quads with a corner on the frame edge or weak edge contrast (<0.06). (b) A fixed 30 px merge radius split "Hello" into five stickers. Fix: radius = 5× median stroke width, clamped to [15, 200]. Four real-photo regression tests added. | commit `6be22e6`; `src/wbx/rectify.py:24-77` | VERIFIED |
| 4 | 2026-09-15 10:48 | Four more iPad samples (`IMG_0877–0880`), each a close-up of one quote; bare-board run `out/nomarker` 15:20 | EXIF; `out/nomarker/manifest.json` mtime | VERIFIED |
| 5 | 2026-09-25 11:37:54 → 11:42:24 | **The shoot.** 56 photos of one long board, a stretch at a time, on a Samsung SM-G981U at 4032×1816. 4.5 minutes in total. | filenames + EXIF of `photos/*.jpg` | VERIFIED |
| 6 | 2026-09-26 01:04 → 01:12 | **59 hand-lassoed crops** saved as RGBA screenshots (`samples/cropped/Screenshot 2026-09-26 0104xx…0112xx.png`) | filenames; `PIL` mode = RGBA for all 59 | VERIFIED (that they exist) / UNVERIFIED (who made them) |
| 7 | 2026-09-26 01:45–01:59 | Pre-cropped-input path: `io.py` (alpha-aware load) and `normalize.py` (inpainted exclusion) last modified | mtimes | INFERRED |
| 8 | 2026-09-26 02:11 | **Intermediate, never-committed version** run on all 59 crops (`out/cropped`) and the 6 iPad samples. Its manifests carry a `single_quote` parameter and no `deglare`, `board_mask`, `keep` or `bg_ink_chroma`. The code that produced them exists in no commit. | `out/cropped/*/manifest.json` param keys vs `src/wbx/pipeline.py:26-50` | VERIFIED |
| 9 | 2026-09-26 02:11 | Same version re-run on `exampletext`: merge radius 320 px. The ≈60 px of commit `6be22e6` is gone, so the switch to the letter-height merge rule had already happened. | `out/exampletext/manifest.json` | VERIFIED |
| 10 | 2026-09-29 09:32–09:37 | Album/handover (`album.py`, `sheet.py`); low-res album of 58 stickers (`out/stickers`) | mtimes; `out/stickers/index.csv` | VERIFIED (mtime) |
| 11 | 2026-09-29 09:58–10:40 | Merge rule rewritten (letter height, union-find on boxes), `board.py`, `recut.py`, deglare and refit changes in `clean.py`/`pipeline.py` | mtimes | INFERRED |
| 12 | 2026-09-29 10:02 | 56 originals copied into `photos/` | mtimes of `photos/*` | VERIFIED |
| 13 | 2026-09-29 10:42–10:44 | **Re-cut to full resolution and re-extracted**: 56 dirs in `out/hires`, album `out/stickers_hires` (56 stickers) | mtimes; dir counts | VERIFIED |
| 14 | 2026-09-29 10:53 | `out/stickers_hires.zip` (31.8 MB) | mtime, size | VERIFIED |
| 15 | 2026-09-29 11:09 | Two manual corrections: `sticker_23_REPLACEMENT_from_55.png`, `sticker_50_rotated_cw.png` | `out/corrections/` | VERIFIED (exist) / UNVERIFIED (how made) |
| 16 | 2026-09-29 11:15–11:21 | **Handover set `out/send/`: 47 stickers**, NOTES.txt, alt/. 33 files byte-identical to pipeline output; **14 modified by a process not in the repository** | `scripts/s01_inventory.py` → `data/inventory.json` | VERIFIED |
| 17 | 2026-09-29 13:19 | **v2 — "Handle real board photos".** +1503/−70 lines: crop masks, glare, two-pass refit with chroma mask, board-region masking, SIFT re-cut, album with duplicate flags. Committed on branch `hires-stickers-and-glare-fixes`; `main` stays at `6be22e6`. Different Claude session (`session_018UExet…`). | commit `0a999a4`; `git branch -vv` | VERIFIED |
| 18 | after 13:19 | `test_real_handwriting_is_one_sticker` recorded as failing in the local pytest cache | `.pytest_cache/v/cache/lastfailed` | VERIFIED (no timestamp in the cache file itself) |

## Iteration count (defensible)

* **3 commits**, **2 Claude Code sessions**, **1 branch** unmerged into `main`.
* **≥ 4 distinguishable code versions** that left artefacts: v1 (`b4bde13`), v1.1
  (`6be22e6`), the uncommitted 2026-09-26 version (row 8), and v2 (`0a999a4`).
* **3 merge-radius rules**: fixed 30 px → 5× stroke width → 0.7× letter height
  (box union-find). Sources: `6be22e6` message; `git show 6be22e6:src/wbx/stickers.py:16`;
  `src/wbx/stickers.py:16-75`.
* **1 real shoot** (56 photos, 59 crops) plus **6 iPad calibration photos**.

## What git does not show

v2 was built over about four days (2026-09-26 → 09-29) and committed once. Its
internal order (rows 7–16) comes only from mtimes and manifest parameter sets.
None of the reasoning recorded in comments (e.g. "slack needed ranged from 4.7
to 13.7 stroke widths", `stickers.py:287`) has a data file behind it.
