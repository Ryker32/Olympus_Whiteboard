# Questions Only You Can Answer

Each question names the claim it unlocks. Answering them is what turns the
UNDETERMINED items in `ATTRIBUTION_AND_AI.md` into either a claim or an omission.

## Authorship and process (highest priority)

**Q1. What did you tell Claude, and what did it decide?**
Open the two session transcripts: `claude.ai/code/session_01PEMay3JkUCYgJfcGLZ9ntH`
(v1 and v1.1) and `claude.ai/code/session_018UExetvr4UGAWWgeyGembV` (v2).
For each of these decisions, was it (a) your idea, (b) Claude's proposal that
you evaluated and accepted, or (c) Claude's without discussion?
- modelling ink as translucent over the board and unmixing it (vs thresholding)
- darkness **OR** saturation as the alpha cue
- testing glare on the **darkest** channel (the yellow-marker insight)
- the two-pass background refit
- feature matching (SIFT + RANSAC) instead of correlation for re-cutting
- letter height instead of stroke width for the merge radius
- the shape-AND-colour duplicate rule
*Unlocks:* Contributions §B and Talking points §F of the card. Without answers,
present these as decisions *you directed and validated*, not *you invented*.

**Q2. Who wrote "M1–M6"?** The v1 commit title implies a milestone plan
existed before the code. Was it a spec you wrote, or Claude's plan?
*Unlocks:* "I specified the system" vs "I prompted a pipeline".

**Q3. Did you read, modify or debug any code by hand?** No commit shows
human-only edits. Even one specific bug you diagnosed yourself (e.g. noticing
that "Hello" split into five, or that rectification warped the board) is
worth naming.

## Data provenance

**Q4. Who drew the 59 lasso crops** (`samples/cropped/`, 2026-09-26 01:04–01:12),
and in what tool? *Unlocks:* "I hand-segmented 59 quotes" as a claim.

**Q5. Who made the 14 post-pipeline edits in `out/send/`** (the "film-removal
pass", the sticker_50 rotation and coverage lift, the sticker_23 swap)? With
what code or tool? Does that code still exist anywhere? *Unlocks:* whether the
delivered set can be called pipeline output.

**Q6. Who made the duplicate cull** (`out/send/alt/*_dupe.png`)? I used it as
ground truth to score the detector (precision 8/8, recall 8/9). If Claude made
the cull, that "ground truth" is not independent.

**Q7. Crops 010559 and 010602: same quote or not?** The `album.py` docstring
("duplicates 0.58–1.00, closest unrelated 0.34") is exactly reproduced only if
this pair counts as *different* quotes (they correlate 0.339). The handover cull
treats them as the *same* quote. Your answer decides whether the detector's
recall is 8/9 or 8/8.

## Purpose, users, outcome

**Q8. What was this actually for?** The README says "students write memories
… for the senior spread layout" (a yearbook). The shoot photos are get-well
messages to "Mr. Grant" ("Get well principal!"). Was the deliverable a
get-well card or collage, a yearbook page, or both? Who received
`stickers_hires.zip` / `out/send`, and was it used? *Unlocks:* the
objective, the users and the outcome on the card. There is currently **zero**
evidence of adoption.

**Q9. Is there a final printed or designed artefact** (photo of the card,
the yearbook page, a PDF layout)? That would be the strongest single figure,
and it is not in the repository.

**Q10. Why is the repo called "Olympus_Whiteboard"?** (Club, school, team
name?) Only the folder and GitHub remote use the name. The package is `wbx` /
`whiteboard-extract`.

## Consent and privacy (must resolve before publishing anything)

**Q11. Do you have permission to publish the handwriting?** The photos and
stickers contain students' first names (e.g. Nina, Kate, Max E., Sean, Simone
Reck in NOTES.txt) and a staff member's name. An MIT portfolio is a publication.
Options: get consent; use only your own calibration shots ("Hello",
`IMG_0877–0880` if you or a consenting person wrote them); or blur names.
**Q11a. Who wrote the four `IMG_0877–0880` samples?** I used `IMG_0877` for the
pipeline-stage figure.

## Housekeeping

**Q12. Is `hires-stickers-and-glare-fixes` pushed?** `main` tracks
`origin/main: gone`. I did not touch the network. If the reviewers will see
the GitHub repo, `main` currently lacks all of v2.

**Q13. Do you want the stale README line and the failing test fixed?**
`README.md:238` still documents "5× the median stroke width". The code uses 0.7×
letter height (`src/wbx/stickers.py:16`). `tests/test_synthetic.py:319` still
expects 40–120 px and now gets 319 px. I did not modify either (audit-only).
